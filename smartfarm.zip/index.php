<?php
require 'vendor/autoload.php'; // Include the necessary MongoDB libraries

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

$mongoClient = new MongoDB\Client(getenv('MONGO_URI')); // Connect to MongoDB

$app = new \Slim\App();

// Define routes
$app->get('/', function ($request, $response, $args) {
    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        $user = $mongoClient->Project->users->findOne(['_id' => new MongoDB\BSON\ObjectID($_SESSION['user_id'])]);

        if ($user) {
            $username = $user['username'];
            $privlidge = $user['privlidge'];

            if (isset($user['profile_image'])) {
                return $this->view->render($response, 'home.html', ['username' => $username, 'privlidge' => $privlidge, 'profile_pic' => $user['profile_image']]);
            }
            
            return $this->view->render($response, 'home.html', ['username' => $username, 'privlidge' => $privlidge]);
        }
    }

    return $this->view->render($response, 'home.html');
});

$app->run();
